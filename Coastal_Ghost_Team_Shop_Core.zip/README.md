# Coastal Ghost Team Shop — Combined Working Project

This project combines:
- Recovered Netlify Agent Runner site source and functionality.
- Team Shop Master Files mockups and official branding assets.

## Site functionality retained
- Shop by Design
- Shop by Item Type
- Shop by Fit & Size Range
- DTF Transfers
- Color selection with mockup updates
- Placement selection where available
- Size selection
- Quantity selection
- Family Order cart and calculated totals
- Review order / checkout flow

## Structure
- `index.html` — site entry point
- `css/` — styling
- `js/` — catalog, cart, and checkout behavior
- `data/` — recovered product/catalog/pricing data
- `assets/master-files/` — full Team Shop Master Files image library, preserving its organization
- `reference/` — master product list workbook and branding palette

The image references used by the recovered site were remapped to the corresponding files in `assets/master-files/`, so the site no longer depends on the missing Netlify deploy asset folder.

## Important
The catalog data currently reflects the recovered Netlify site's product catalog. The complete Master Files image library is included and preserved, ready for future catalog expansion and pricing updates.


## Combined v2
This version preserves the recovered website project and adds the newly reorganized Team Shop Master Files under `assets/catalog/`. The new master structure is intentionally preserved as supplied, including nested product ZIP archives extracted into their matching catalog folders. This version is intended as the new working baseline after path shortening and additional assets.
